#ifndef CM_VERSION_H
#define CM_VERSION_H

#define WEAPTFC_VERSION "2.1"

#endif //CM_VERSION_H